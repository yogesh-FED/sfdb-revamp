import React from 'react';
import {
  App,
  View,
  Page,
  Navbar,
  Toolbar,
  Link,
  Tabs,
  Tab,
} from 'framework7-react';
import TabStructure from './tabStructure';

const CategoriesSchemes = ({ language_data, tnClass }) => {


  return (
    <>
      <h3>Categories</h3>
    </>
  );
};
export default { CategoriesSchemes };